package com.example.dicegame

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private lateinit var player1NameInput: EditText
    private lateinit var player2NameInput: EditText
    private lateinit var roundsInput: EditText
    private lateinit var resultTextView: TextView
    private lateinit var playButton: Button
    private lateinit var resetButton: Button

    private var player1Score: Int = 0
    private var player2Score: Int = 0
    private var rounds: Int = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Связываем UI-компоненты с кодом
        player1NameInput = findViewById(R.id.player1NameInput)
        player2NameInput = findViewById(R.id.player2NameInput)
        roundsInput = findViewById(R.id.roundsInput)
        resultTextView = findViewById(R.id.resultTextView)
        playButton = findViewById(R.id.playButton)
        resetButton = findViewById(R.id.resetButton)

        playButton.setOnClickListener {
            startGame()
        }

        resetButton.setOnClickListener {
            resetGame()
        }
    }

    private fun rollDice(): Int {
        return Random.nextInt(1, 7)
    }

    private fun startGame() {
        // Получаем имена игроков и количество раундов
        val player1 = player1NameInput.text.toString().ifBlank { "Player 1" }
        val player2 = player2NameInput.text.toString().ifBlank { "Player 2" }
        rounds = roundsInput.text.toString().toIntOrNull() ?: 1
        player1Score = 0
        player2Score = 0

        val resultText = StringBuilder()

        for (round in 1..rounds) {
            val player1Roll = rollDice()
            val player2Roll = rollDice()

            resultText.append("Раунд $round: $player1 бросил $player1Roll, $player2 бросил $player2Roll\n")

            when {
                player1Roll > player2Roll -> {
                    player1Score++
                    resultText.append("$player1 выиграл раунд!\n")
                }
                player1Roll < player2Roll -> {
                    player2Score++
                    resultText.append("$player2 выиграл раунд!\n")
                }
                else -> {
                    resultText.append("Ничья в раунде!\n")
                }
            }
            resultText.append("\n")
        }

        // Итоги игры
        resultText.append("Игра завершена!\n")
        resultText.append("$player1: $player1Score очков, $player2: $player2Score очков\n")

        when {
            player1Score > player2Score -> resultText.append("Победитель: $player1!")
            player1Score < player2Score -> resultText.append("Победитель: $player2!")
            else -> resultText.append("Итоговая ничья!")
        }

        // Отображаем результат на экране
        resultTextView.text = resultText.toString()
    }

    private fun resetGame() {
        player1NameInput.text.clear()
        player2NameInput.text.clear()
        roundsInput.text.clear()
        resultTextView.text = ""
        player1Score = 0
        player2Score = 0
    }
}
